
package aryanemachado290323;

/**
 *
 * @author aryan
 */
public class Onibus {
    
        private String cor;
        private String modeloOnibus;

//------------------------------------------
    public Onibus(String modeloOnibus, String cor){
       
    this.modeloOnibus = modeloOnibus;
    this.cor = cor;
    
    } // fim contrutor 1 onibus
    
//-------------------------------------------    
    
    public String getCor() {
        return cor;
    }

    /**
     * @param cor the cor to set
     */
    public void setCor(String cor) {
        this.cor = cor;
    }

    /**
     * @return the modeloOnibus
     */
    public String getModeloOnibus() {
        return modeloOnibus;
    }

    /**
     * @param modeloOnibus the modeloOnibus to set
     */
    public void setModeloOnibus(String modeloOnibus) {
        this.modeloOnibus = modeloOnibus;
    }
    

    
    
}
