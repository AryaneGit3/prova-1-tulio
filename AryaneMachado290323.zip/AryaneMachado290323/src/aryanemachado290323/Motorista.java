
package aryanemachado290323;

/**
 *
 * @author aryan
 */
public class Motorista {
    
    private String nome;
    private String cnpj;
    private String CPF;
    private double salario;
    
    //-------------------------------------------
    public Motorista(String nome, String cnpj, String CPF, double salario){
    this.nome = nome;
    this.cnpj = cnpj;
    this.CPF = CPF;
    this.salario = salario;
    
    } // fim construtor 1
    
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cnpj
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * @param cnpj the cnpj to set
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    /**
     * @return the CPF
     */
    public String getCPF() {
        return CPF;
    }

    /**
     * @param CPF the CPF to set
     */
    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    //-------------------------------------------------------
    

    
}
