
package aryanemachado290323;

/**
 *
 * @author aryan
 */
public class Viagem {

 
     
    private String CPFidViagem;
    private String destino;
    private double distancia;
    private double valorKM;
    private double qtdValorViagens;
    private double valorViagem;
    
    //----------------------------------------------
    public Viagem(String CPFidViagem, String destino,double distancia, double valorKM  ){ 
 
    this.CPFidViagem = CPFidViagem;
    this.destino = destino;
    this.distancia = distancia;
    this.valorKM = valorKM;


    } // fim construtor 1 viagem 
    
       /**
     * @return the CPFidViagem
     */
    public String getCPFidViagem() {
        return CPFidViagem;
    }

    /**
     * @param CPFidViagem the CPFidViagem to set
     */
    public void setCPFidViagem(String CPFidViagem) {
        this.CPFidViagem = CPFidViagem;
    }
      
    public String getidViagem() {
        return CPFidViagem;
    }
    /**
     * @param idViagem the idViagem to set
     */
    public void setIdViagem(String idViagem) {
        this.setCPFidViagem(idViagem);
    }

    /**
     * @return the destino
     */
    public String getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(String destino) {
        this.destino = destino;
    }

    /**
     * @return the valorKM
     */
    public double getValorKM() {
        return valorKM;
    }

    /**
     * @param valorKM the valorKM to set
     */
    public void setValorKM(double valorKM) {
        this.valorKM = valorKM;
    }

    /**
     * @return the valorViagem
     */
    public double getValorViagem() {
        return valorViagem;
    }

    /**
     * @param valorViagem the valorViagem to set
     */
    public void setValorViagem(double valorViagem) {
        this.valorViagem = valorViagem;
    }

    /**
     * @return the distancia
     */
    public double getDistancia() {
        return distancia;
    }

    /**
     * @param distancia the distancia to set
     */
    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    /**
     * @return the qtdValorViagens
     */
    public double getQtdValorViagens() {
        return qtdValorViagens;
    }

    /**
     * @param qtdValorViagens the qtdValorViagens to set
     */
    public void setQtdValorViagens(double qtdValorViagens) {
        this.qtdValorViagens = qtdValorViagens;
    }
    //--------------------------------------------------------------------------------
   
    // Método para calcular o valor de uma viagem:
    
   public void calculoViagem(){
       
        this.setValorViagem(this.getDistancia() * this.getValorKM());
          
    //---------------------------------------------------------------------------------
    
    
          
}

}