
package aryanemachado290323;

/**
 *
 * @author aryan
 */
public class Teste {
    
    public static void main(String[] args) {
        
    
    
    Onibus onibus1 = new Onibus("Mercedez4500", "Azul");
    Motorista motorista1 = new Motorista("Joao Aguiar", "450.000.000-89", "459.569.899-56", 4.500);
    Viagem viagem1 = new Viagem("129.836.396-90", "Angra dos Reis",390, 20.00);
    
    Cliente cliente1 = new Cliente("Aryane Cassimiro Machado", motorista1, viagem1, onibus1);
    cliente1.relatorioViagem();
    
            
        
        
    
    
    
    
    }
    
    
    
}
