
package aryanemachado290323;

/**
 *
 * @author aryan
 */
public class Cliente { 
    
    private String nome;
    private String CPF;
    private String RG;
    private Motorista m1; 
    private Viagem viagem1;  
    private Onibus onibus; 
 
    //----------------------------------------------------------------
      Cliente(String nome, Motorista m1, Viagem viagem1, Onibus onibus){
          
        this.nome = nome;
        this.m1 = m1;
        this.viagem1 = viagem1;
        this.onibus = onibus;     
        
      } // fim construtor 1 cliente 
      
    //-----------------------------------------------------------------  
   
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the CPF
     */
    public String getCPF() {
        return CPF;
    }

    /**
     * @param CPF the CPF to set
     */
    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    /**
     * @return the RG
     */
    public String getRG() {
        return RG;
    }

    /**
     * @param RG the RG to set
     */
    public void setRG(String RG) {
        this.RG = RG;
    }

    /**
     * @return the m1
     */
    public Motorista getM1() {
        return m1;
    }

    /**
     * @param m1 the m1 to set
     */
    public void setM1(Motorista m1) {
        this.m1 = m1;
    }

    /**
     * @return the viagem1
     */
    public Viagem getViagem1() {
        return viagem1;
    }

    /**
     * @param viagem1 the viagem1 to set
     */
    public void setViagem1(Viagem viagem1) {
        this.viagem1 = viagem1;
    }

    /**
     * @return the onibus
     */
    public Onibus getOnibus() {
        return onibus;
    }

    /**
     * @param onibus the onibus to set
     */
    public void setOnibus(Onibus onibus) {
        this.onibus = onibus;
    }
    
    //----------------------------------------------
       public void relatorioViagem(){
        
        System.out.println("Nome do cliente: "+getNome());
        System.out.println("Nome do motorista: "+this.getM1().getNome());
        System.out.println("Modelo do onibus: "+this.getOnibus().getModeloOnibus());
        System.out.println("Identificador da viagem (CPF do Cliente de Entrada): "+this.getViagem1().getCPFidViagem());
        System.out.println("Destino da Viagem: "+this.getViagem1().getDestino());
        System.out.println("Valor do KM: "+this.getViagem1().getValorKM());
        System.out.println("Quilometragem (Distancia): "+this.getViagem1().getDistancia());
        System.out.println("Valor total da viagem: "+this.getViagem1().getValorViagem());
                                                    
    }
       
       
    
   
    
}
